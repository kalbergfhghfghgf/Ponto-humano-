package com.toquefacil.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Path
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random

class PointerView(
    c: android.content.Context,
    private val n: Int,
    private val shape: Int,
    private val col: Int,
    a: Int
) : View(c) {
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)

    init { alpha = a / 100f }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val r = w / 2f
        pa.color = col
        when (shape) {
            0 -> {
                pa.style = Paint.Style.STROKE
                pa.strokeWidth = w / 10
                cv.drawCircle(r, r, r - w / 10, pa)
                pa.style = Paint.Style.FILL
                pa.textSize = w / 2.4f
                pa.textAlign = Paint.Align.CENTER
                cv.drawText("$n", r, r + w / 8, pa)
            }
            1 -> {
                pa.style = Paint.Style.STROKE
                pa.strokeWidth = w / 12
                cv.drawCircle(r, r, r * 0.6f, pa)
                cv.drawLine(r, 0f, r, w, pa)
                cv.drawLine(0f, r, w, r, pa)
            }
            2 -> {
                pa.style = Paint.Style.FILL
                cv.drawCircle(r, r, r * 0.6f, pa)
            }
            else -> {
                pa.style = Paint.Style.FILL
                pa.textSize = w * 0.9f
                pa.textAlign = Paint.Align.CENTER
                cv.drawText("☝", r, r + w * 0.3f, pa)
            }
        }
    }
}

class ClickService : AccessibilityService() {

    companion object { var inst: ClickService? = null }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private var bar: View? = null
    private var playBtn: TextView? = null
    private val views = mutableListOf<View>()
    private val lps = mutableListOf<WindowManager.LayoutParams>()
    private var running = false
    private var clicks = 0
    private var startT = 0L

    private fun cfg() = getSharedPreferences("cfg", 0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeAll()
        inst = null
        return super.onUnbind(intent)
    }

    private fun mkLp(w: Int, hh: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, hh,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun makeDraggable(touch: View, root: View, lp: WindowManager.LayoutParams, canDrag: () -> Boolean) {
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        touch.setOnTouchListener { _, e ->
            if (!canDrag()) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
    }

    fun showBar() {
        if (bar != null) return
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            background = GradientDrawable().apply {
                setColor(0xE61F1F1F.toInt())
                cornerRadius = dp(24).toFloat()
            }
        }
        fun btn(t: String, f: () -> Unit) = TextView(this@ClickService).apply {
            text = t
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener { f() }
        }
        val handle = btn("≡") {}
        val play = btn("▶") { setRunning(!running) }
        playBtn = play
        ll.addView(handle)
        ll.addView(play)
        ll.addView(btn("＋") { if (!running) addPointer() })
        ll.addView(btn("－") { if (!running) removePointer() })
        ll.addView(btn("⚙") {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        ll.addView(btn("✕") { removeAll() })
        val lp = mkLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(8), dp(160))
        makeDraggable(handle, ll, lp) { true }
        wm.addView(ll, lp)
        bar = ll
        if (lps.isEmpty()) addPointer()
    }

    private fun addPointer(px: Int = -1, py: Int = -1) {
        if (lps.size >= 8) return
        val c = cfg()
        val size = dp(c.getInt("size", 36))
        val dm = resources.displayMetrics
        val n = lps.size
        val x = if (px >= 0) px else dm.widthPixels / 2 + n * dp(30) - size / 2
        val y = if (py >= 0) py else dm.heightPixels / 3 + n * dp(60)
        val colors = intArrayOf(0xFF378ADD.toInt(), 0xFFE24B4A.toInt(), 0xFF1D9E75.toInt(), 0xFFBA7517.toInt(), 0xFF7F77DD.toInt())
        val v = PointerView(this, n + 1, c.getInt("shape", 0), colors[c.getInt("color", 0).coerceIn(0, 4)], c.getInt("alpha", 90))
        val lp = mkLp(size, size, x, y)
        makeDraggable(v, v, lp) { !running }
        wm.addView(v, lp)
        views.add(v)
        lps.add(lp)
    }

    private fun removePointer() {
        if (views.size <= 1) return
        wm.removeView(views.removeAt(views.size - 1))
        lps.removeAt(lps.size - 1)
    }

    fun refresh() {
        if (bar == null) return
        val keep = lps.map { Pair(it.x, it.y) }
        views.forEach { wm.removeView(it) }
        views.clear()
        lps.clear()
        keep.forEach { addPointer(it.first, it.second) }
    }

    private fun removeAll() {
        running = false
        h.removeCallbacksAndMessages(null)
        views.forEach { wm.removeView(it) }
        views.clear()
        lps.clear()
        bar?.let { wm.removeView(it) }
        bar = null
        playBtn = null
    }

    private fun setRunning(on: Boolean) {
        if (on && lps.isEmpty()) return
        running = on
        playBtn?.text = if (on) "❚❚" else "▶"
        for (i in views.indices) {
            val l = lps[i]
            l.flags = if (on) l.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            else l.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            wm.updateViewLayout(views[i], l)
        }
        if (on) {
            clicks = 0
            startT = SystemClock.uptimeMillis()
            h.postDelayed({ tick() }, 300)
        } else {
            h.removeCallbacksAndMessages(null)
        }
    }

    private fun delayMs(): Long {
        val c = cfg()
        val v = c.getInt("dv", 3).toLong()
        return when (c.getInt("unit", 1)) { 0 -> v; 1 -> v * 1000; else -> v * 60000 }
    }

    private fun tick() {
        if (!running) return
        val c = cfg()
        val stop = c.getInt("stop", 0)
        val sv = c.getInt("sv", 100)
        if ((stop == 1 && clicks >= sv) || (stop == 2 && (SystemClock.uptimeMillis() - startT) / 1000 >= sv) || lps.isEmpty()) {
            setRunning(false)
            return
        }
        val vary = c.getBoolean("vary", true)
        val mode = c.getInt("mode", 0)
        val jit = if (vary) dp(5) else 0

        fun pt(i: Int): PointF {
            val l = lps[i]
            return PointF(
                l.x + l.width / 2f + (rnd.nextFloat() * 2 - 1) * jit,
                l.y + l.height / 2f + (rnd.nextFloat() * 2 - 1) * jit
            )
        }

        val targets = when (mode) {
            2 -> lps.indices.map { pt(it) }
            1 -> listOf(pt(clicks % lps.size))
            else -> listOf(pt(0))
        }
        val dur = when {
            mode == 3 -> 800L
            vary -> 40L + rnd.nextInt(80)
            else -> 50L
        }
        val b = GestureDescription.Builder()
        for (t in targets) {
            val p = Path()
            p.moveTo(t.x, t.y)
            p.lineTo(t.x + 1f, t.y)
            b.addStroke(GestureDescription.StrokeDescription(p, 0, dur))
        }
        val cb = object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { clicks++; next() }
            override fun onCancelled(g: GestureDescription?) { next() }
        }
        if (!dispatchGesture(b.build(), cb, null)) next()
    }

    private fun next() {
        if (!running) return
        val c = cfg()
        var d = delayMs()
        if (c.getBoolean("vary", true)) {
            val v = c.getInt("vp", 20) / 100f
            d = (d * (1 + (rnd.nextFloat() * 2 - 1) * v)).toLong()
        }
        h.postDelayed({ tick() }, maxOf(d, 40L))
    }
}
