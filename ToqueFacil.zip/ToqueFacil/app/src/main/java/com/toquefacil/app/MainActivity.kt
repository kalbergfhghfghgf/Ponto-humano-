package com.toquefacil.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var eDelay: EditText
    private lateinit var sUnit: Spinner
    private lateinit var sStop: Spinner
    private lateinit var eStopVal: EditText
    private lateinit var sMode: Spinner
    private lateinit var cVary: CheckBox
    private lateinit var eVar: EditText
    private lateinit var sShape: Spinner
    private lateinit var sColor: Spinner
    private lateinit var skSize: SeekBar
    private lateinit var skAlpha: SeekBar

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(0xFF666666.toInt())
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun spin(items: List<String>, sel: Int) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
    }

    private fun num(v: Int) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(v.toString())
    }

    private fun card(vararg v: android.view.View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(8), dp(16), dp(16))
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(16).toFloat()
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12)
        layoutParams = lp
        v.forEach { addView(it) }
    }

    private fun bigBtn(t: String, filled: Boolean, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 16f
        setTextColor(if (filled) Color.WHITE else 0xFF185FA5.toInt())
        background = GradientDrawable().apply {
            setColor(if (filled) 0xFF185FA5.toInt() else 0x1A185FA5)
            cornerRadius = dp(28).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) }
        setOnClickListener { f() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("cfg", 0)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(28))
            setBackgroundColor(0xFFF1F3F7.toInt())
        }
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)

        col.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            setTextColor(0xFF1F1F1F.toInt())
            gravity = Gravity.START
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(6), 0, dp(6)) }
        col.addView(status)

        col.addView(bigBtn("Iniciar", true) {
            save()
            val svc = ClickService.inst
            if (svc == null) {
                Toast.makeText(this, "Ative o serviço de acessibilidade primeiro", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                svc.showBar()
                moveTaskToBack(true)
            }
        })
        col.addView(bigBtn("Ativar acessibilidade", false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        eDelay = num(p.getInt("dv", 3))
        sUnit = spin(listOf("Milissegundos", "Segundos", "Minutos"), p.getInt("unit", 1))
        sStop = spin(listOf("Loop infinito", "Número de cliques", "Tempo total (segundos)"), p.getInt("stop", 0))
        eStopVal = num(p.getInt("sv", 100))
        col.addView(card(
            label("Tempo até o próximo clique"), eDelay, sUnit,
            label("Condição de parada"), sStop,
            label("Valor da condição (cliques ou segundos)"), eStopVal
        ))

        sMode = spin(listOf("Toque único", "Multitoque (um por vez)", "Toque sincronizado", "Pressionar e segurar"), p.getInt("mode", 0))
        col.addView(card(label("Modo"), sMode))

        sShape = spin(listOf("Anel", "Mira", "Ponto", "Dedo"), p.getInt("shape", 0))
        sColor = spin(listOf("Azul", "Vermelho", "Verde", "Âmbar", "Roxo"), p.getInt("color", 0))
        skSize = SeekBar(this).apply { max = 44; progress = p.getInt("size", 36) - 20 }
        skAlpha = SeekBar(this).apply { max = 70; progress = p.getInt("alpha", 90) - 30 }
        col.addView(card(
            label("Formato do ponteiro"), sShape,
            label("Cor"), sColor,
            label("Tamanho"), skSize,
            label("Transparência"), skAlpha
        ))

        cVary = CheckBox(this).apply { text = "Variar tempo e posição dos toques"; isChecked = p.getBoolean("vary", true) }
        eVar = num(p.getInt("vp", 20))
        col.addView(card(cVary, label("Variação do tempo (%)"), eVar))

        col.addView(bigBtn("Salvar", true) {
            save()
            Toast.makeText(this, "Salvo", Toast.LENGTH_SHORT).show()
        })
    }

    private fun save() {
        getSharedPreferences("cfg", 0).edit()
            .putInt("dv", eDelay.text.toString().toIntOrNull() ?: 3)
            .putInt("unit", sUnit.selectedItemPosition)
            .putInt("stop", sStop.selectedItemPosition)
            .putInt("sv", eStopVal.text.toString().toIntOrNull() ?: 100)
            .putInt("mode", sMode.selectedItemPosition)
            .putBoolean("vary", cVary.isChecked)
            .putInt("vp", (eVar.text.toString().toIntOrNull() ?: 20).coerceIn(0, 90))
            .putInt("shape", sShape.selectedItemPosition)
            .putInt("color", sColor.selectedItemPosition)
            .putInt("size", skSize.progress + 20)
            .putInt("alpha", skAlpha.progress + 30)
            .apply()
        ClickService.inst?.refresh()
    }

    override fun onResume() {
        super.onResume()
        val on = ClickService.inst != null
        status.text = if (on) "Serviço ativo. Toque em Iniciar." else "Serviço desativado. Toque em Ativar acessibilidade e ligue o Toque Fácil."
        status.setTextColor(if (on) 0xFF3B6D11.toInt() else 0xFFA32D2D.toInt())
    }
}
